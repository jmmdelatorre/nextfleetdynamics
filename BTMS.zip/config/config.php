<?php
// config/config.php
return [
    'db' => [
        'host' => 'localhost',
        'dbname' => 'btms',
        'user' => 'root',
        'pass' => '',
    ],
];
