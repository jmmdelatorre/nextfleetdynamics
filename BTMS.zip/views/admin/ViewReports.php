<!-- views/admin/ViewReports.php -->

<?php
$title = 'View Reports'; // Set the page title
require __DIR__ . '/../main.php'; // Include the main layout
?>

<div class="container-fluid">
    <div class="row">
        <!-- Include the sidebar -->
        <?php include __DIR__ . '/../SideBar.php'; ?>

        <!-- Main content area -->
        <div class="col-md-9 col-lg-10 main-content">
            <div class="container mt-5">
                <header class="text-center">
                    <h1>View Reports</h1>
                </header>
            </div>
        </div>
    </div>
</div>