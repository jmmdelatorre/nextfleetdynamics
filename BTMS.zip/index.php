<?php
// Redirect to public/index.php
header('Location: public/index.php');
exit;
